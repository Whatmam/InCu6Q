#!/bin/sh

usage(){
        echo "Usage : ${0} [SD_DEV]"
        echo " ex) ${0} sdc"
}

if [ ! $1 ]; then
        usage
        exit
fi

#DISK=/dev/$1
DISK=$1

# make  partition
BOOT_ROM_SIZE=10
DATA_SIZE=400
FS_START=`expr $BOOT_ROM_SIZE + $DATA_SIZE`
FS_SIZE=14000

dd if=/dev/zero of=${DISK} bs=1024 count=1
sfdisk --force -uM ${DISK} << EOF
${BOOT_ROM_SIZE},${DATA_SIZE},b
${FS_START},${FS_SIZE},83
EOF

